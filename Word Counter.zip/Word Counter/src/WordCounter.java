import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Takes input .txt file from user and outputs list of words and how often they
 * appear in a .html file that the user specifies.
 *
 * Note: Did the Additional Activity for not counting capitalization.
 *
 * @author Vinamra Agrawal
 */
public final class WordCounter {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private WordCounter() {
        // no code needed here
    }

    /**
     * Checks whether s is in the sequence wordSeq.
     *
     * @param s
     *            the string being checked
     * @param wordSeq
     *            the sequence being used to check s
     * @return whether or not s is in wordSeq
     * @requires wordSeq.length() > 0
     * @ensures checkInSequence = [s is in sequence]
     */
    public static boolean checkInSequence(String s, Sequence<String> wordSeq) {
        //output variable
        boolean outCheck = false;
        //check strings in wordSeq
        for (int i = 0; i < wordSeq.length(); i++) {
            //if s is in wordSeq, sets outCheck to true and ends loop
            if (wordSeq.entry(i).equals(s)) {
                outCheck = true;
                i = wordSeq.length();
            }
        }
        //return result
        return outCheck;
    }

    /**
     * Gets word (all characters except separators) starting from position pos
     * or the separator at position pos.
     *
     * @requires 0 <= pos < s.length
     * @param s
     *            String to get word from
     * @param pos
     *            position of the start of the word
     * @param separators
     *            list of separators to stop checking for word
     * @return the word from position pos or the separator at position pos
     * @ensures getWordOrSeparator = [all characters as a string up to a
     *          separator starting at position pos or a separator at position
     *          pos if character at pos is a separator]
     */
    public static String getWordOrSeparator(String s, int pos,
            Sequence<String> separators) {
        //String to output
        String getString = "";
        /*
         * i is the current position for the loop while pos is the starting
         * position of the loop
         */
        int currPos = pos;
        //counter for substring
        int count = 0;
        /*
         * loops while i doesn't exceed the string length and the current
         * character is the same (separator or letter) as the character at pos.
         */
        while (currPos < s.length()
                && checkInSequence(s.substring(currPos, currPos + 1),
                        separators) == checkInSequence(
                                s.substring(pos, pos + 1), separators)) {
            count++;
            currPos++;
        }
        getString = s.substring(pos, pos + count);
        return getString;
    }

    /**
     * Sorts word to be in alphabetical order and keeps count in order.
     *
     * @param word
     *            Sequence of words to be sorted by alphabetical order
     * @param listCount
     *            Sequence of counts to be sorted in order of word
     * @updates word
     * @updates count
     * @requires <pre>
     * word.length() > 0
     * count.length() > 0
     * </pre>
     * @ensures <pre>
     * word = [#word in alphabetical order]
     * count = [#count in order matching word]
     * </pre>
     */
    public static void sortAlpha(Sequence<String> word,
            Sequence<Integer> listCount) {
        //check all the strings in word except the last one
        for (int i = 0; i < word.length() - 1; i++) {
            /*
             * check all the strings in word starting from 1 ahead of i to the
             * last one
             */
            for (int j = i + 1; j < word.length(); j++) {
                /*
                 * if the string in word that comes first should alphabetically
                 * come second, switch the word and its count
                 */
                if (word.entry(i).toLowerCase()
                        .compareTo(word.entry(j).toLowerCase()) > 0) {
                    String temp = word.entry(i);
                    word.replaceEntry(i, word.entry(j));
                    word.replaceEntry(j, temp);
                    int temp2 = listCount.entry(i);
                    listCount.replaceEntry(i, listCount.entry(j));
                    listCount.replaceEntry(j, temp2);
                }
            }
        }
    }

    /**
     * Gets Sequence of counts for each word with count positions correlating
     * with positions of words in listWords. Removes repeat words in listWords.
     *
     * @param listWords
     *            list of Words for sorting
     * @updates listWords
     * @return Sequence of counts
     * @ensures <pre>
     * getListCount = sequence of counts in order
     * listWords = [#listWords without repeat words]
     * </pre>
     */
    public static Sequence<Integer> getListCount(Sequence<String> listWords) {
        //list of counts
        Sequence<Integer> list = new Sequence1L<Integer>();
        //make list of counts not empty
        for (int k = 0; k < listWords.length(); k++) {
            list.add(k, 1);
        }
        /*
         * loops through list of words and increases list count value for word
         * if more than 1 exist and removes repeated words
         */
        for (int i = 0; i < listWords.length() - 1; i++) {
            for (int j = i + 1; j < listWords.length(); j++) {
                if (listWords.entry(j).equals(listWords.entry(i))) {
                    list.replaceEntry(i, list.entry(i) + 1);
                    listWords.remove(j);
                    j--;
                }
            }
        }
        return list;
    }

    /**
     * Gets list of all words in s in order of appearance.
     *
     * @param s
     *            String of words
     * @param separators
     *            Sequence of separator strings
     * @return Sequence of words
     * @ensures getListOfWords = [Sequence of all words in s in order of
     *          appearance]
     */
    public static Sequence<String> getListOfWords(String s,
            Sequence<String> separators) {
        //list of words for output
        Sequence<String> list = new Sequence1L<String>();
        //current position in string
        int pos = 0;
        //position in sequence
        int counter = 0;
        /*
         * loops till the end of the string, checks if getWordOrSeparator is a
         * word or separator then adds it if it is a word
         */
        while (pos < s.length()) {
            String word = getWordOrSeparator(s, pos, separators);
            if (!checkInSequence(word.substring(0, 1), separators)) {
                list.add(counter, word);
                counter++;
                pos += word.length() + 1;
            } else {
                pos += word.length();
            }
        }
        return list;
    }

    /**
     * Gets file lines as 1 big string.
     *
     * @param inFile
     *            file to read from
     * @return file as 1 string
     * @ensures buildString = [1 string with all lines from inFile]
     */
    public static String buildString(SimpleReader inFile) {
        //loops till the end of the file and adds each line to the string
        String build = inFile.nextLine();
        while (!inFile.atEOS()) {
            build += " ";
            build += inFile.nextLine();
        }
        return build;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        //SimpleWriter and SimpleReader for main
        SimpleWriter outMain = new SimpleWriter1L();
        SimpleReader inMain = new SimpleReader1L();

        //get input
        outMain.print("Enter name of input file: ");
        String inFileName = inMain.nextLine();
        SimpleReader inFile = new SimpleReader1L(inFileName);

        //get output
        outMain.print("Enter name of output file: ");
        String outFileName = inMain.nextLine();
        SimpleWriter outFile = new SimpleWriter1L(outFileName);

        //build string and sequence of separators
        String s = buildString(inFile);
        Sequence<String> separators = new Sequence1L<String>();
        separators.add(0, " ");
        separators.add(0, ",");
        separators.add(0, ";");
        separators.add(0, "/");
        separators.add(0, "\\");
        separators.add(0, "-");
        separators.add(0, "_");
        separators.add(0, "=");
        separators.add(0, ".");
        separators.add(0, "?");
        separators.add(0, "!");
        separators.add(0, "\"");

        //get list of words and counts for each word then sort them
        Sequence<String> listWords = getListOfWords(s, separators);
        Sequence<Integer> listCount = getListCount(listWords);
        sortAlpha(listWords, listCount);

        //output to file
        outFile.println("<html>");
        outFile.println("   <head>");
        outFile.println(
                "       <title>Words Counted in " + inFileName + "</title>");
        outFile.println("   </head>");
        outFile.println("   <body>");
        outFile.println("       <h2>Words Counted in " + inFileName + "</h2>");
        outFile.println("       <hr />");
        outFile.println("       <table border=\"1\">");
        outFile.println("           <tr>");
        outFile.println("               <th>Words</th>");
        outFile.println("               <th>Counts</th>");
        outFile.println("           </tr>");
        //loops for each word adding it to the table
        for (int i = 0; i < listWords.length(); i++) {
            outFile.println("           <tr>");
            outFile.println(
                    "               <td>" + listWords.entry(i) + "</td>");
            outFile.println(
                    "               <td>" + listCount.entry(i) + "</td>");
            outFile.println("           </tr>");
        }
        outFile.println("       </table>");
        outFile.println("   </body>");
        outFile.println("</html>");

        outMain.close();
        inMain.close();
        inFile.close();
    }

}
