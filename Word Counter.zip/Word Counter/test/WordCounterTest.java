import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.sequence.Sequence;
import components.sequence.Sequence1L;

public class WordCounterTest {

    //Tests for checkInSequence

    @Test
    public void testCheckInSequence_Standard_True() {
        String s = "dog";
        Sequence<String> seq = new Sequence1L<String>();
        seq.add(0, "cat");
        seq.add(0, "dog");
        seq.add(0, "mouse");
        boolean test = WordCounter.checkInSequence(s, seq);
        assertEquals(true, test);
        assertEquals("dog", s);
        assertEquals("mouse", seq.entry(0));
        assertEquals("dog", seq.entry(1));
        assertEquals("cat", seq.entry(2));
    }

    @Test
    public void testCheckInSequence_Standard_False() {
        String s = "dog";
        Sequence<String> seq = new Sequence1L<String>();
        seq.add(0, "cat");
        seq.add(0, "bird");
        seq.add(0, "mouse");
        boolean test = WordCounter.checkInSequence(s, seq);
        assertEquals(false, test);
        assertEquals("dog", s);
        assertEquals("mouse", seq.entry(0));
        assertEquals("bird", seq.entry(1));
        assertEquals("cat", seq.entry(2));
    }

    //Tests for getWordOrSeparator

    @Test
    public void testgetWordOrSeparator_Standard_Bird() {
        Sequence<String> separators = new Sequence1L<String>();
        separators.add(0, " ");
        separators.add(0, ",");
        separators.add(0, ";");
        separators.add(0, "/");
        separators.add(0, "\\");
        separators.add(0, "-");
        separators.add(0, "_");
        separators.add(0, "=");
        separators.add(0, ".");
        separators.add(0, "?");
        separators.add(0, "!");
        separators.add(0, "\"");
        String s = "a bird flew across the sky.";
        String test = WordCounter.getWordOrSeparator(s, 2, separators);
        assertEquals("bird", test);
        assertEquals("a bird flew across the sky.", s);
    }

    @Test
    public void testgetWordOrSeparator_Standard_Sky() {
        Sequence<String> separators = new Sequence1L<String>();
        separators.add(0, " ");
        separators.add(0, ",");
        separators.add(0, ";");
        separators.add(0, "/");
        separators.add(0, "\\");
        separators.add(0, "-");
        separators.add(0, "_");
        separators.add(0, "=");
        separators.add(0, ".");
        separators.add(0, "?");
        separators.add(0, "!");
        separators.add(0, "\"");
        String s = "a bird flew across the sky.";
        String test = WordCounter.getWordOrSeparator(s, 23, separators);
        assertEquals("sky", test);
        assertEquals("a bird flew across the sky.", s);
    }

    @Test
    public void testgetWordOrSeparator_Boundary_Sky() {
        Sequence<String> separators = new Sequence1L<String>();
        separators.add(0, " ");
        separators.add(0, ",");
        separators.add(0, ";");
        separators.add(0, "/");
        separators.add(0, "\\");
        separators.add(0, "-");
        separators.add(0, "_");
        separators.add(0, "=");
        separators.add(0, ".");
        separators.add(0, "?");
        separators.add(0, "!");
        separators.add(0, "\"");
        String s = "a bird flew across the sky";
        String test = WordCounter.getWordOrSeparator(s, 23, separators);
        assertEquals("sky", test);
        assertEquals("a bird flew across the sky", s);
    }

    @Test
    public void testgetWordOrSeparator_Boundary_Y() {
        Sequence<String> separators = new Sequence1L<String>();
        separators.add(0, " ");
        separators.add(0, ",");
        separators.add(0, ";");
        separators.add(0, "/");
        separators.add(0, "\\");
        separators.add(0, "-");
        separators.add(0, "_");
        separators.add(0, "=");
        separators.add(0, ".");
        separators.add(0, "?");
        separators.add(0, "!");
        separators.add(0, "\"");
        String s = "a bird flew across the sky";
        String test = WordCounter.getWordOrSeparator(s, 25, separators);
        assertEquals("y", test);
        assertEquals("a bird flew across the sky", s);
    }

    @Test
    public void testgetWordOrSeparator_Standard_Separators() {
        Sequence<String> separators = new Sequence1L<String>();
        separators.add(0, " ");
        separators.add(0, ",");
        separators.add(0, ";");
        separators.add(0, "/");
        separators.add(0, "\\");
        separators.add(0, "-");
        separators.add(0, "_");
        separators.add(0, "=");
        separators.add(0, ".");
        separators.add(0, "?");
        separators.add(0, "!");
        separators.add(0, "\"");
        String s = "a///   ????bird flew across the sky.";
        String test = WordCounter.getWordOrSeparator(s, 1, separators);
        assertEquals("///   ????", test);
        assertEquals("a///   ????bird flew across the sky.", s);
    }
}
